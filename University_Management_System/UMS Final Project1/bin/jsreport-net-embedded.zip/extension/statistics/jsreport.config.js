﻿module.exports = {
  "name": "statistics",
  "main": "lib/statistics.js",
  "dependencies": [ "templates", "reports" ]
}