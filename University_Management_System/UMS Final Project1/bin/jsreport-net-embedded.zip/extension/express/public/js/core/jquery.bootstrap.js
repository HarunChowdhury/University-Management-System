﻿/*! 
 * Copyright(c) 2014 Jan Blaha 
 */ 

define([], function () {
});