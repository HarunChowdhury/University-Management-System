﻿module.exports = {
  "name": "express",
  "main": "lib/reporter.express.js"  
}