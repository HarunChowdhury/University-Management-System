﻿module.exports = {
  "name": "fop-pdf",
  "main": "lib/fop.js",
  "hasPublicPart": false
}