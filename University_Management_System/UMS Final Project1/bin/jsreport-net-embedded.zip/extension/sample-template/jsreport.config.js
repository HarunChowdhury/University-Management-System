﻿module.exports = {
  "name": "sample-template",
  "main": "lib/sample.js",
  "dependencies": [ "templates", "data", "phantom-pdf" ],
  "hasPublicPart": false
}